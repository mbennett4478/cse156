/**
 * Created by TheWoz on 11/6/14.
 */
public class DataInfo {
    public static final String url = "jdbc:mysql://cse.unl.edu/khanso";
    public static final String username = "khanso";
    public static final String password = "sqldatabase7";
}
