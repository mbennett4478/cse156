/**
 * Created by TheWoz on 10/14/14.
 */
public interface Parse {
    public String jsonProducer();
}
